#include <webots/motor.h>
#include <webots/robot.h>
#include <webots/camera.h>
#include <webots/camera_recognition_object.h>
#include <stdio.h>
#include <string.h>
#include <webots/touch_sensor.h>


// time in [ms] of a simulation step
#define TIME_STEP 64

// entree point of the controller
int main(int argc, char **argv) {
  // initialise the Webots API
  wb_robot_init();
  WbDeviceTag camera;
  WbDeviceTag bumper;

    /* Get the camera device, enable it and the recognition */
  camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, TIME_STEP);
  wb_camera_recognition_enable(camera, TIME_STEP);
  bumper = wb_robot_get_device("bumper");
  wb_touch_sensor_enable(bumper, TIME_STEP);
  
  // internal variables
  int i;
  double left_speed, right_speed;

  // initialise motors
  WbDeviceTag wheels[4];
  char wheels_names[4][8] = {"wheel1", "wheel2", "wheel3", "wheel4"};
  for (i = 0; i < 4; i++) {
    wheels[i] = wb_robot_get_device(wheels_names[i]);
    wb_motor_set_position(wheels[i], INFINITY);
  }

  // feedback loop
  while (wb_robot_step(TIME_STEP) != -1) {
    // init speeds
    const WbCameraRecognitionObject *objects = wb_camera_recognition_get_objects(camera);
      if (objects[0].position_on_image[0] > 140)
      {
    wb_motor_set_velocity(wheels[0], 6.0);
    wb_motor_set_velocity(wheels[1], -6.0);
    wb_motor_set_velocity(wheels[2], 6.0);
    wb_motor_set_velocity(wheels[3], -6.0);
       printf("Turning right \n");
      }
      else if (objects[0].position_on_image[0] < 110)
      {
    wb_motor_set_velocity(wheels[0], -6.0);
    wb_motor_set_velocity(wheels[1], 6.0);
    wb_motor_set_velocity(wheels[2], -6.0);
    wb_motor_set_velocity(wheels[3], 6.0);
       printf("Turning left \n");
      }
     else if (wb_touch_sensor_get_value(bumper) > 0)
      {
    wb_motor_set_velocity(wheels[0], 0.0);
    wb_motor_set_velocity(wheels[1], 0.0);
    wb_motor_set_velocity(wheels[2], 0.0);
    wb_motor_set_velocity(wheels[3], 0.0);
       printf("Ball passed! \n");
       break;
      }
     else
      {
    wb_motor_set_velocity(wheels[0], 10.0);
    wb_motor_set_velocity(wheels[1], 10.0);
    wb_motor_set_velocity(wheels[2], 10.0);
    wb_motor_set_velocity(wheels[3], 10.0);
       printf("Passing the ball! \n");
      } 
  }

  // cleanup the Webots API
  wb_robot_cleanup();
  return 0;  // EXIT_SUCCESS
}
