import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';

export default function AddRestaurantScreen({ onBack }) {
  const [restaurantName, setRestaurantName] = useState('');
  const [cuisine, setCuisine] = useState('');
  const [deliveryTime, setDeliveryTime] = useState('');
  const [rating, setRating] = useState('');
  const [distance, setDistance] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = () => {
    Alert.alert(
      'Future Functionality',
      'In the final version, this form will:\n\n' +
      '• Validate all input fields\n' +
      '• Upload restaurant images\n' +
      '• Save data to backend database\n' +
      '• Add restaurant to live listings\n' +
      '• Send confirmation notification\n' +
      '• Update user dashboard\n\n' +
      'Data Structure (JSON):\n' +
      '{\n' +
      '  "id": "auto-generated",\n' +
      '  "name": "' + (restaurantName || 'Restaurant Name') + '",\n' +
      '  "cuisine": "' + (cuisine || 'Cuisine Type') + '",\n' +
      '  "rating": ' + (rating || '0') + ',\n' +
      '  "deliveryTime": "' + (deliveryTime || '0') + ' min",\n' +
      '  "distance": "' + (distance || '0') + ' km",\n' +
      '  "description": "...",\n' +
      '  "imageUrl": "url",\n' +
      '  "menuItems": [],\n' +
      '  "reviews": [],\n' +
      '  "createdAt": "timestamp"\n' +
      '}',
      [{ text: 'OK' }]
    );
  };

  const handleImageUpload = () => {
    Alert.alert(
      'Future Feature',
      'Image upload will include:\n\n' +
      '• Camera integration\n' +
      '• Gallery selection\n' +
      '• Image cropping\n' +
      '• Multiple image support\n' +
      '• Cloud storage (Firebase/AWS)',
      [{ text: 'OK' }]
    );
  };

  const handleLocationPicker = () => {
    Alert.alert(
      'Future Feature',
      'Location picker will include:\n\n' +
      '• Google Maps integration\n' +
      '• GPS coordinates\n' +
      '• Address autocomplete\n' +
      '• Distance calculation\n' +
      '• Delivery zone validation',
      [{ text: 'OK' }]
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#f97316" />
      
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={onBack}>
          <Text style={styles.backButtonText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add Restaurant</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.formContainer}>
          
          <TouchableOpacity style={styles.imageUploadBox} onPress={handleImageUpload}>
            <Text style={styles.imageUploadIcon}>📸</Text>
            <Text style={styles.imageUploadText}>Upload Restaurant Image</Text>
            <Text style={styles.imageUploadSubtext}>Tap to select from gallery</Text>
          </TouchableOpacity>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Restaurant Name *</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., Italian Bistro"
              placeholderTextColor="#9ca3af"
              value={restaurantName}
              onChangeText={setRestaurantName}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Cuisine Type *</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., Italian, Japanese, Mexican"
              placeholderTextColor="#9ca3af"
              value={cuisine}
              onChangeText={setCuisine}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Rating *</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., 4.5"
              placeholderTextColor="#9ca3af"
              keyboardType="decimal-pad"
              value={rating}
              onChangeText={setRating}
            />
            <Text style={styles.helperText}>Enter rating between 1.0 - 5.0</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Delivery Time (minutes) *</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., 30"
              placeholderTextColor="#9ca3af"
              keyboardType="number-pad"
              value={deliveryTime}
              onChangeText={setDeliveryTime}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Distance (km) *</Text>
            <TouchableOpacity onPress={handleLocationPicker}>
              <View style={[styles.input, styles.locationInput]}>
                <Text style={distance ? styles.locationText : styles.locationPlaceholder}>
                  {distance || 'Pick location to calculate'}
                </Text>
                <Text style={styles.locationIcon}>📍</Text>
              </View>
            </TouchableOpacity>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Describe the restaurant, specialties, ambiance..."
              placeholderTextColor="#9ca3af"
              multiline
              numberOfLines={4}
              value={description}
              onChangeText={setDescription}
            />
          </View>

          <View style={styles.prototypeNote}>
            <Text style={styles.prototypeNoteTitle}>📝 Prototype Note</Text>
            <Text style={styles.prototypeNoteText}>
              Additional fields in final version:{'\n\n'}
              • Opening/Closing hours{'\n'}
              • Contact information{'\n'}
              • Website & social media{'\n'}
              • Delivery fee{'\n'}
              • Minimum order amount{'\n'}
              • Payment methods accepted{'\n'}
              • Special dietary options{'\n'}
              • Restaurant verification status
            </Text>
          </View>

          <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
            <Text style={styles.submitButtonText}>Add Restaurant</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.infoButton}
            onPress={() => Alert.alert(
              'Database Structure (ERD)',
              'RESTAURANTS Table:\n' +
              '- id (PK)\n' +
              '- name\n' +
              '- cuisine_type\n' +
              '- rating\n' +
              '- delivery_time\n' +
              '- distance\n' +
              '- image_url\n' +
              '- created_at\n\n' +
              'MENU_ITEMS Table:\n' +
              '- id (PK)\n' +
              '- restaurant_id (FK)\n' +
              '- name\n' +
              '- price\n' +
              '- category\n\n' +
              'ORDERS Table:\n' +
              '- id (PK)\n' +
              '- user_id (FK)\n' +
              '- restaurant_id (FK)\n' +
              '- total_amount\n' +
              '- status',
              [{ text: 'OK' }]
            )}
          >
            <Text style={styles.infoButtonText}>📊 View Database Structure (ERD)</Text>
          </TouchableOpacity>

          <View style={{ height: 40 }} />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    backgroundColor: '#f97316',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 50,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 32,
    color: '#fff',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  formContainer: {
    padding: 24,
  },
  imageUploadBox: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#e5e7eb',
    borderStyle: 'dashed',
  },
  imageUploadIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  imageUploadText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  imageUploadSubtext: {
    fontSize: 14,
    color: '#6b7280',
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#1f2937',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  helperText: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 4,
    fontStyle: 'italic',
  },
  locationInput: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 16,
    color: '#1f2937',
  },
  locationPlaceholder: {
    fontSize: 16,
    color: '#9ca3af',
  },
  locationIcon: {
    fontSize: 20,
  },
  prototypeNote: {
    backgroundColor: '#fef3c7',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#fbbf24',
  },
  prototypeNoteTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#92400e',
    marginBottom: 8,
  },
  prototypeNoteText: {
    fontSize: 14,
    color: '#78350f',
    lineHeight: 20,
  },
  submitButton: {
    backgroundColor: '#f97316',
    padding: 18,
    borderRadius: 30,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  submitButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  infoButton: {
    backgroundColor: '#e0e7ff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 16,
    borderWidth: 1,
    borderColor: '#6366f1',
  },
  infoButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4338ca',
  },
});