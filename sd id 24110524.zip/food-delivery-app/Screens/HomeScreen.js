import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';

const restaurants = [
  { id: 1, name: "Italian Bistro", cuisine: "Italian", rating: 4.8, time: "25-30 min", image: "🍝", distance: "1.2 km" },
  { id: 2, name: "Sushi Master", cuisine: "Japanese", rating: 4.9, time: "30-35 min", image: "🍣", distance: "2.1 km" },
  { id: 3, name: "Burger House", cuisine: "American", rating: 4.6, time: "20-25 min", image: "🍔", distance: "0.8 km" },
  { id: 4, name: "Taco Fiesta", cuisine: "Mexican", rating: 4.7, time: "25-30 min", image: "🌮", distance: "1.5 km" },
  { id: 5, name: "Thai Delight", cuisine: "Thai", rating: 4.8, time: "35-40 min", image: "🍜", distance: "3.2 km" },
  { id: 6, name: "Pizza Palace", cuisine: "Italian", rating: 4.5, time: "25-30 min", image: "🍕", distance: "1.8 km" },
];

export default function HomeScreen({ onAddRestaurant }) {
  const categories = ['All', '🍕 Pizza', '🍔 Burgers', '🍣 Sushi', '🌮 Mexican', '🍜 Asian'];

  const handleRestaurantClick = (restaurant) => {
    Alert.alert(
      'Future Feature',
      `In the final version, clicking "${restaurant.name}" will show:\n\n` +
      '• Full menu with items\n' +
      '• Add to cart functionality\n' +
      '• Real-time order tracking\n' +
      '• Reviews and ratings\n' +
      '• Special offers',
      [{ text: 'OK' }]
    );
  };

  const handleCategoryClick = () => {
    Alert.alert(
      'Future Feature',
      'In the final version, categories will:\n\n' +
      '• Filter restaurants in real-time\n' +
      '• Show relevant cuisine types\n' +
      '• Update dynamically based on location',
      [{ text: 'OK' }]
    );
  };

  const handleSearchFocus = () => {
    Alert.alert(
      'Future Feature',
      'Search functionality will include:\n\n' +
      '• Real-time search results\n' +
      '• Search by restaurant name\n' +
      '• Search by cuisine type\n' +
      '• Search by dish name\n' +
      '• Voice search capability',
      [{ text: 'OK' }]
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#f97316" />
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.headerTop}>
            <View>
              <Text style={styles.greeting}>Hey, Foodie! 👋</Text>
              <View style={styles.locationContainer}>
                <Text style={styles.locationIcon}>📍</Text>
                <Text style={styles.locationText}>Current Location</Text>
              </View>
            </View>
          </View>
          
          <TouchableOpacity onPress={handleSearchFocus}>
            <View style={styles.searchContainer}>
              <Text style={styles.searchIcon}>🔍</Text>
              <Text style={styles.searchPlaceholder}>Search restaurants or dishes...</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.categoriesSection}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesScroll}>
            {categories.map((cat, index) => (
              <TouchableOpacity
                key={index}
                style={styles.categoryButton}
                onPress={handleCategoryClick}
              >
                <Text style={styles.categoryButtonText}>{cat}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.restaurantsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Nearby Restaurants</Text>
            <TouchableOpacity onPress={onAddRestaurant}>
              <Text style={styles.addButton}>+ Add New</Text>
            </TouchableOpacity>
          </View>
          
          {restaurants.map((restaurant) => (
            <TouchableOpacity
              key={restaurant.id}
              style={styles.restaurantCard}
              onPress={() => handleRestaurantClick(restaurant)}
            >
              <Text style={styles.restaurantImage}>{restaurant.image}</Text>
              <View style={styles.restaurantInfo}>
                <Text style={styles.restaurantName}>{restaurant.name}</Text>
                <Text style={styles.restaurantCuisine}>{restaurant.cuisine} Cuisine</Text>
                <View style={styles.restaurantMeta}>
                  <Text style={styles.restaurantMetaItem}>⭐ {restaurant.rating}</Text>
                  <Text style={styles.restaurantMetaItem}>⏱️ {restaurant.time}</Text>
                  <Text style={styles.restaurantMetaItem}>📍 {restaurant.distance}</Text>
                </View>
              </View>
              <Text style={styles.chevron}>›</Text>
            </TouchableOpacity>
          ))}

          <View style={styles.prototypeNote}>
            <Text style={styles.prototypeNoteTitle}>📝 Prototype Note</Text>
            <Text style={styles.prototypeNoteText}>
              This is a basic list display. Final version will include:{'\n\n'}
              • Real-time filtering & sorting{'\n'}
              • User reviews & ratings{'\n'}
              • Favorite restaurants{'\n'}
              • Distance-based sorting{'\n'}
              • Restaurant availability status{'\n'}
              • Special deals & promotions{'\n'}
              • API integration for live data
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    backgroundColor: '#f97316',
    padding: 24,
    paddingTop: 50,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerTop: {
    marginBottom: 24,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationIcon: {
    fontSize: 14,
    marginRight: 4,
  },
  locationText: {
    fontSize: 14,
    color: '#fff',
    opacity: 0.9,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 30,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  searchIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  searchPlaceholder: {
    fontSize: 16,
    color: '#999',
  },
  categoriesSection: {
    paddingHorizontal: 24,
    paddingVertical: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 12,
  },
  categoriesScroll: {
    flexDirection: 'row',
  },
  categoryButton: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 12,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  categoryButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4b5563',
  },
  restaurantsSection: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  addButton: {
    fontSize: 16,
    color: '#f97316',
    fontWeight: '600',
  },
  restaurantCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  restaurantImage: {
    fontSize: 60,
    marginRight: 16,
  },
  restaurantInfo: {
    flex: 1,
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 4,
  },
  restaurantCuisine: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 8,
  },
  restaurantMeta: {
    flexDirection: 'row',
    gap: 12,
  },
  restaurantMetaItem: {
    fontSize: 14,
    color: '#4b5563',
    marginRight: 12,
  },
  chevron: {
    fontSize: 24,
    color: '#9ca3af',
  },
  prototypeNote: {
    backgroundColor: '#fef3c7',
    padding: 16,
    borderRadius: 12,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#fbbf24',
  },
  prototypeNoteTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#92400e',
    marginBottom: 8,
  },
  prototypeNoteText: {
    fontSize: 14,
    color: '#78350f',
    lineHeight: 20,
  },
});