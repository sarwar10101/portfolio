import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import WelcomeScreen from './Screens/WelcomeScreen';
import HomeScreen from './Screens/HomeScreen';
import AddRestaurantScreen from './Screens/AddRestaurantScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('welcome');

  const handleGetStarted = () => {
    setCurrentScreen('home');
  };

  const handleAddRestaurant = () => {
    setCurrentScreen('add');
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
  };

  return (
    <View style={styles.container}>
      {currentScreen === 'welcome' && (
        <WelcomeScreen onGetStarted={handleGetStarted} />
      )}
      
      {currentScreen === 'home' && (
        <HomeScreen onAddRestaurant={handleAddRestaurant} />
      )}
      
      {currentScreen === 'add' && (
        <AddRestaurantScreen onBack={handleBackToHome} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
